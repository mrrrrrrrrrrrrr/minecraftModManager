﻿#include<iostream>
#include<vector>
#include<map>
#include<string>
#include<random>

using namespace std;

string genRandKey(int length) { //генерация рандомной строки - ключа из заданного алфавита значений alphavit
	string key = "";

	static const char alphavit[] =
		"0123456789"
		"abcdefghijklmnopqrstuvwxyz"
		"ABCDEFGHIJKLMNOPQRSTUVWXYZ";

	random_device rd;
	mt19937 gen(rd());
	uniform_int_distribution<> dis(0, sizeof(alphavit) - 1);

	for (int i = 0; i < length; i++) {
		key += alphavit[dis(gen)];
	}

	return key;
}

void createMap(map<char, int>& dictionary) { //заполнение словарей алфавитом английских маленьких и больших букв, а также цифр от 0 до 9
	char firstLetter = 'a';
	char firstLetterUpCase = 'A';
	char firstNumber = '0';

	for (int i = 0; i <= 25; i++) {
		dictionary[firstLetter] = i;
		firstLetter++;
	}

	for (int i = 26; i <= 51; i++) {
		dictionary[firstLetterUpCase] = i;
		firstLetterUpCase++;
	}

	for (int i = 52; i <= 61; i++) {
		dictionary[firstNumber] = i;
		firstNumber++;
	}
}

void createReturnMap(map<int, char>& dictionary) {
	char firstLetter = 'a';
	char firstLetterUpCase = 'A';
	char firstNumber = '0';

	for (int i = 0; i <= 25; i++) {
		dictionary[i] = firstLetter;
		firstLetter++;
	}

	for (int i = 26; i <= 51; i++) {
		dictionary[i] = firstLetterUpCase;
		firstLetterUpCase++;
	}

	for (int i = 52; i <= 61; i++) {
		dictionary[i] = firstNumber;
		firstNumber++;
	}

}

void printMap(map<char, int>& dictionary) { //для удобства реализована функция вывода на основе конструкции pair. она представляет из себя пару элементов, чем и наполнен словарь
	for (const auto& pair : dictionary) { // цикл проходится по всем парам ключ - значение словаря, где pair.first - значение (неизменяемое), pair.second - ключ, он изменяемый. в алгоритме шифровки это сильно поможет
		cout << pair.first << ":" << pair.second << endl;
	}
}


void printReturnMap(map<int, char>& dictionary) {
	for (const auto& pair : dictionary) {
		cout << pair.first << ":" << pair.second << endl;
	}
}

void CryptMap(string key, int key2, map<char, int>& cryptMap) {

	int keySum = 0; //ключ 1 уровня, представляет из себя число сдвига, является суммой позиций символов в ключе
	for (int i = 0; i < key.length(); i++) {
		keySum += cryptMap[key[i]];
	}

	// шифровка словаря, где key2 - ключ 2 уровня, число сдвига, которое применяется для символов, что соответствуют ключу
	// алгоритм шифровки работает по следующему принципу: 1 итерация - меняются местами символы словаря, что соответствуют ключу и символ, что находитcя на keySum+key2 (сдвиг)
	// 2 итерация - сдвиг всех символов алфавита на keySum
	// дальше записываем в вектор позиции символов кодируемого слова в зашифрованном словаре, а после транслируем эти позиции в оригинальном словаре - получаем зашифрованное слово
	// алгоритм предполагает усиление защиты посредством добавления новых итераций, которые будут последовательно менять словарь, расшифровать который получится только имея определенный набор ключей
	int tempSPos;
	int tempFPos = 0;
	for (auto& pair : cryptMap) { // 1 итерация
		for (int j = 0; j < key.length(); j++) {
			if (pair.first == key[j]) {
				tempSPos = pair.second;
				char tempChar = pair.first;

				tempFPos = tempSPos + (keySum + key2);
				tempFPos %= 62;
				for (auto& pair : cryptMap) {
					if (pair.second == tempFPos) {
						pair.second = tempSPos;
						break;
					}
				}

				pair.second += (keySum + key2);
				pair.second %= 62;

				break;
			}

		}
	}

	for (auto& pair : cryptMap) { // 2 итерация
		pair.second += keySum;
		pair.second %= 62;
	}
}

string crypt(string word, string key, int key2) {
	
	map<int, char> ReturnMap; //инициализация словаря символ - ключ и словаря ключ - символ
	map<char, int> cryptMap;
	createReturnMap(ReturnMap);
	createMap(cryptMap); 

	CryptMap(key, key2, cryptMap); //шифровка словаря
	
	vector<int> cryptPos; //сюда запишу позиции символов слова в зашифрованном словаре
	for (int i = 0; i < word.length(); i++) {
		cryptPos.push_back(cryptMap[word[i]]);
	}

	for (int i = 0; i < word.length(); i++) { //позиции слова в зашифрованном словаре вывожу как позиции этого слова в оригинальном словаре. получаю зашифрованное слово
		word[i] = ReturnMap[cryptPos[i]];
	}

	cout << "Ключ 1 уровня - " << key << endl;
	cout << "Ключ 2 уровня - " << key2 << endl;
	cout << "Сохраните ключи для дальнейшей дешифровки" << endl << endl;
	return word;
}

string encrypt (string cryptWord, string key, int key2) {

	map<char, int> Smap; //чистый словарь (неизмененный)
	createMap(Smap);

	map<char, int> cryptMap; //создание зашифрованного словаря по ключам
	createMap(cryptMap);
	CryptMap(key, key2, cryptMap);

	vector<int> cryptPos; // запишу позиции зашифрованного слова в вектор 
	for (int i = 0; i < cryptWord.length(); i++) {
		cryptPos.push_back(Smap[cryptWord[i]]);
	}

	for (int i = 0; i < cryptWord.length(); i++) { //я не могу обратиться напрямую к ключам, чтобы провести обратную дешифровку. создавать обратный шифрованный словарь впадлу, потому прохожусь по всем парам словаря через pair и ищу совпадения с позицией символа ключа
		for (auto& pair : cryptMap) {
			if (cryptPos[i] == pair.second) cryptWord[i] = pair.first;
		}
	}


	return cryptWord;
}



int main() {
	setlocale(LC_ALL, "Russian");
	srand(time(0)); //для большей безопасности длина ключа будет случайной, но диапозон указывает пользователь, тем самым задавая сложность 1 ключа

	string word; //слово для шифровки\дешифровки
	int key, key2; //пользовательские ключи. первый - максимальная длина генерируемого ключа, второй - вторичный сдвиг в случае совпадения символов ключа с символом словаря, третий - ключ 1-го уровня для дешифровки
	string keyStr;
	int AMOGUS, ANANAS; //режимы работы программы

	map<char, int> dictionary;
	while (1 > 0) {
		cout << "Выберите режим: 1 - шифрование. 2 - дешифрование, 3 - выход из программы" << endl;
		cin >> AMOGUS;
		if (AMOGUS == 1) {
			cout << "Введите слово для шифровки по алгоритму шифрования 'Ананас1488капибара' -" << endl;
			cin >> word;
			cout << "Сгенерировать ключи самостоятельно? Да - 1. Нет - 2" << endl;
			cin >> ANANAS;
			if (ANANAS == 2) {
				cout << "Укажите сложность ключа 1-го уровня" << endl;
				cin >> key;
				cout << "Введите сложность ключа 2-го уровня" << endl;
				cin >> key2;
			}
			if (ANANAS == 1) {
				key = rand() % (10 - 5 + 1) + 5;
				key2 = rand() % (61 - 1 + 1) + 1;
			}
			cout << "Зашифрованное слово - " << crypt(word, genRandKey(key), key2) << endl;
		}

		if (AMOGUS == 2) {
			cout << "Введите слово для дешифровки по алгоритму шифрования 'Ананас1488капибара'" << endl;
			cin >> word;
			cout << "Введите ключ 1-го уровня" << endl;
			cin >> keyStr;
			cout << "Введите ключ 2-го уровня" << endl;
			cin >> key2;
			cout << "Дешифрованное слово - " << encrypt(word, keyStr, key2) << endl;
		}

		if (AMOGUS == 3) break;
		

	}
}