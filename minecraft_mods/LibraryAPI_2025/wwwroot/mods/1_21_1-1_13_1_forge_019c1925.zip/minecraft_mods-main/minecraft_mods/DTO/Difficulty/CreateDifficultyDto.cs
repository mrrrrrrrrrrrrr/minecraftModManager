﻿namespace DTO.Difficulty;

public class CreateDifficultyDto
{
    public string Title { get; set; } = "";
    public DateTime CreatedAt { get; set; }
    public DateTime UpdatedAt { get; set; }
}